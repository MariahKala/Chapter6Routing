﻿using Microsoft.AspNetCore.Mvc;

namespace MVCRouting.Areas.Admin.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Detail(int id)
        {
            return Content("Admin controller, More action, id: " + id);
        }
    }
}
