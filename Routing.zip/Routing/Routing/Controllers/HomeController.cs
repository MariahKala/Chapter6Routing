﻿using Microsoft.AspNetCore.Mvc;

namespace Routing.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Assignments()
        {
            return View();
        }


        public IActionResult Admin()
        {
            return View();
        }

        
       //Custom Route
        public IActionResult Custom(int id)
        {
            return Content("Home controller, Custom action, id: " + id);
        }
        //Custom route with route attribute

        [Route("Home/{id}")]
        public IActionResult List(string id, int num)
        {
            return Content("Home controller, List action, " + "Category " + id + ", Page " + num);
        }

        
    }
}